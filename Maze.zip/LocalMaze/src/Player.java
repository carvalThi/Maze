import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Player extends Remote {
	
	String getName() throws RemoteException;
    int getX() throws RemoteException;
    int getY() throws RemoteException;
    int getNbTreasure() throws RemoteException;
    
    void setName(String s) throws RemoteException;
    void setX(int k) throws RemoteException;
    void setY(int k) throws RemoteException;
    void setNbTreasure(int k) throws RemoteException;
}
