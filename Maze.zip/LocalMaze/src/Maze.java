import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Maze extends Remote {
	
	int getN() throws RemoteException;
	int getM() throws RemoteException;
	int getTreasureLeft() throws RemoteException;
	CellClass[][] getTab() throws RemoteException;
	
	void setN(int k) throws RemoteException;
	void setM(int k) throws RemoteException;
	
    String castString() throws RemoteException;
    
    void moveEast(Player p) throws RemoteException;
	void setTreasureLeft(int k) throws RemoteException;
    void moveWest(Player p) throws RemoteException;
    void moveNorth(Player p) throws RemoteException;
    void moveSouth(Player p) throws RemoteException;
}
