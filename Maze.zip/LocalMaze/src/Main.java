import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.rmi.RemoteException;


public class Main {

	public static void main(String[] args) throws IOException {
		PlayerClass P1 = new PlayerClass("P1 ");
		PlayerClass P2 = new PlayerClass("P2 ");
		PlayerClass P3 = new PlayerClass("P3 ");

		PlayerClass[] list = {P1, P2, P3};
		MazeClass M = new MazeClass(6, 6, list);

		System.out.println(M.castString());

		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

		while(M.getTreasureLeft() > 0){
			System.out.println("Which direction does Player 1 want to go ? (QSDZ) (NSEW)");
			String input = reader.readLine();		
			if (input.equals("z") || input.equals("n")){
				M.moveNorth(P1);
			}
			if (input.equals("s")){
				M.moveSouth(P1);
			}
			if (input.equals("q") || input.equals("w")){
				M.moveWest(P1);
			}
			if (input.equals("d") || input.equals("e")){
				M.moveEast(P1);
			}
			System.out.println(M.castString());
		}


		System.out.println("End of the game, here are the scores :");
		System.out.println(printScores(list));
	}
	
	public static String printScores(Player[] list) throws RemoteException{
		String result = "";
		for (int i = 0; i < list.length ; i++){
			result = result + list[i].getName() + ": " + list[i].getNbTreasure() + "\n";
		}
		return result;
	}
}
