import java.rmi.RemoteException;

public class MazeClass implements Maze {

	private int n ;
	private int m ;
	private int TreasureLeft;
	private CellClass[][] tab;

	public MazeClass(int n, int m, Player[] list) throws RemoteException {
		this.n = n;
		this.m = m;
		this.TreasureLeft = m;
		this.tab = new CellClass[n][n];
		
		for(int i = 0; i < this.n; i++){
			for(int j = 0; j < this.n; j++){
				this.tab[i][j] = new CellClass();
			}
		}
		
		for(int i = 0; i < m; i++){
			int Ri = (int) (Math.random() * n);
			int Rj = (int) (Math.random() * n);
			int k = this.tab[Ri][Rj].getNbTreasure();
			this.tab[Ri][Rj].setNbTreasure(k + 1);
		}

		for(int i = 0; i < list.length; i++){
			int Ri;
			int Rj;
			do {
				Ri = (int) (Math.random() * n);
				Rj = (int) (Math.random() * n);
			} while (this.tab[Ri][Rj].p != null);
			list[i].setX(Ri);
			list[i].setY(Rj);
			this.tab[Ri][Rj].p = list[i];
			if(this.tab[Ri][Rj].nbTreasure != 0){
				this.tab[Ri][Rj].p.setNbTreasure(this.tab[Ri][Rj].nbTreasure);
				System.out.println(list[i].getName()+" found " + this.tab[Ri][Rj].nbTreasure + " treasure(s).");
				this.tab[Ri][Rj].setNbTreasure(0);
			}
		}
	}
	
	@Override
	public int getN() throws RemoteException {
		return this.n;
	}

	@Override
	public int getM() throws RemoteException {
		return this.m;
	}
	
	@Override
	public int getTreasureLeft() throws RemoteException {
		return this.TreasureLeft;
	}

	@Override
	public void setTreasureLeft(int k) throws RemoteException {
		this.TreasureLeft = k;
	}

	@Override
	public CellClass[][] getTab() throws RemoteException {
		return this.tab;
	}

	public void setN(int k) throws RemoteException {
		this.n = k;
	}

	@Override
	public void setM(int k) throws RemoteException {
		this.m = k;
	}

	public String castString() throws RemoteException{
		String result = "";
		String temp;

		for(int i = 0; i < this.n; i++){
			for(int j = 0; j < this.n; j++){
				if (this.tab[i][j].p != null){
					temp = this.tab[i][j].p.getName();
				} else if (this.tab[i][j].nbTreasure != 0){
					temp = " T ";
				} else {
					temp = " . ";
				}
				result = result + temp;
			}
			result = result + "\n";
		}
		return result;
	}

	public void moveEast(Player p) throws RemoteException{
		int k = p.getX();
		int l = p.getY();
		if (this.tab[k][Math.min(l +1,this.n -1)].p != null){
			System.out.println("A player is already there, or you have reached the limits.");
		} else{
			this.tab[k][l].p = null;
			this.tab[k][Math.min(l +1,this.n -1)].p = p;
			p.setX(k);
			p.setY(Math.min(l +1,this.n -1));
		}
		checkMaze(p);
	}

	@Override
	public void moveWest(Player p) throws RemoteException {
		int k = p.getX();
		int l = p.getY();
		if (this.tab[k][Math.max(l -1,0)].p != null){
			System.out.println("A player is already there, or you have reached the limits.");
		} else{
			this.tab[k][l].p = null;
			this.tab[k][Math.max(l -1, 0)].p = p;
			p.setX(k);
			p.setY(Math.max(l -1,0));
		}
		checkMaze(p);
	}

	@Override
	public void moveNorth(Player p) throws RemoteException {
		int k = p.getX();
		int l = p.getY();
		if (this.tab[Math.max(k -1,0)][l].p != null){
			System.out.println("A player is already there, or you have reached the limits.");
		} else{
			this.tab[k][l].p = null;
			this.tab[Math.max(k -1,0)][l].p = p;
			p.setX(Math.max(k -1,0));
			p.setY(l);
		}
		checkMaze(p);
	}

	@Override
	public void moveSouth(Player p) throws RemoteException {
		int k = p.getX();
		int l = p.getY();
		if (this.tab[Math.min(k +1,this.n -1)][l].p != null){
			System.out.println("A player is already there, or you have reached the limits.");
		} else{
			this.tab[k][l].p = null;
			this.tab[Math.min(k +1,this.n -1)][l].p = p;
			p.setX(Math.min(k +1, this.n -1));
			p.setY(l);			
		}
		checkMaze(p);
	}
	
	private void checkMaze(Player p) throws RemoteException{
		int Ri = p.getX();
		int Rj = p.getY();
		
		if(this.tab[Ri][Rj].nbTreasure != 0){
			p.setNbTreasure(p.getNbTreasure() + this.tab[Ri][Rj].nbTreasure);
			System.out.println(p.getName()+" found " + this.tab[Ri][Rj].nbTreasure + " treasure(s).");
			this.tab[Ri][Rj].setNbTreasure(0);
			this.TreasureLeft = this.TreasureLeft - 1;
		}
	}

}





