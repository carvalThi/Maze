import java.rmi.RemoteException;


public class CellClass implements Cell{
	
	Player p;
	int nbTreasure;
	
	public CellClass(){
		this.p=null;
		this.nbTreasure = 0;
	}

	@Override
	public Player getPlayer() throws RemoteException {
		return this.p;
	}

	@Override
	public int getNbTreasure() throws RemoteException {
		return this.nbTreasure;
	}

	@Override
	public void setPlayer(Player p) throws RemoteException {
		this.p = p;
	}

	@Override
	public void setNbTreasure(int k) throws RemoteException {
		this.nbTreasure = k;
	}

}
