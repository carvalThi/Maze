import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Cell extends Remote{
	Player getPlayer() throws RemoteException;
	int getNbTreasure() throws RemoteException;
	
	void setPlayer(Player p) throws RemoteException;
	void setNbTreasure(int k) throws RemoteException;
}
