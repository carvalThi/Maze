import java.rmi.RemoteException;

public class PlayerClass implements Player{

	private String name;
	private int x;
	private int y;
	private int nbTreasure;
	
	public PlayerClass( String s){
		this.name = s;
		this.nbTreasure = 0;
	}
	
	@Override
	public String getName() throws RemoteException {
		return this.name;
	}

	@Override
	public int getX() throws RemoteException {
		return this.x;
	}

	@Override
	public int getY() throws RemoteException {
		return this.y;
	}

	@Override
	public void setName(String s) throws RemoteException {
		this.name = s;
	}

	@Override
	public void setX(int k) throws RemoteException {
		this.x = k;
	}

	@Override
	public void setY(int k) throws RemoteException {
		this.y = k;
	}

	@Override
	public int getNbTreasure() throws RemoteException {
		return this.nbTreasure;
	}

	@Override
	public void setNbTreasure(int k) throws RemoteException {
		this.nbTreasure = k;
	}

}
